
function toggleCard(el){
  const d = el.querySelector('.details');
  d.style.display = (d.style.display === 'block') ? 'none' : 'block';
}
